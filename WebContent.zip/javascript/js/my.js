/* js > my.js */


//document.getElementById("btnCat");

function get(id) {
	return document.getElementById(id);
}
